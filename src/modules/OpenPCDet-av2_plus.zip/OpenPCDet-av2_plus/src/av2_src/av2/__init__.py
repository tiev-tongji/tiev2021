# <Copyright 2022, Argo AI, LLC. Released under the MIT license.>

"""Argoverse 2 API."""

__version__ = "0.2.1"
