# <Copyright 2022, Argo AI, LLC. Released under the MIT license.>

"""Common structures for manipulating sensor data."""
