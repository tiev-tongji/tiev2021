/**
 * \file
 * Implementation of class.
 */
/****************************************************
 * Author: Edmundo LOPEZ
 * email:  lopezed5@etu.unige.ch
 *
 * This code was written as a part of my bachelor
 * thesis at the University of Geneva.
 *
 * $Id$
 *
 * **************************************************/

#include <hello.hh>

int
Hello::foo(int x, int y)
  {
    return x + y;
  }
