// fake qglobal.h
#define QT_VERSION 0x030000
