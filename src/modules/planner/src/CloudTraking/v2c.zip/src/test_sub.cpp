#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <string>
#include <cstring>
#include <cctype>
#include <thread>
#include <chrono>
#include "mqtt/async_client.h"
#include "../proto/TJ_v2x.pb.h"

const std::string SERVER_ADDRESS("tcp://221.181.123.244:22683");
const std::string CLIENT_ID("mec2cloud_001");
const std::string TOPIC("topic/test/mec2cloud/test");
const std::string PASSWORD("mec_123qwe$");
const int QOS = 1;
const int N_RETRY_ATTEMPTS = 5;

class action_listener : public virtual mqtt::iaction_listener
{
    std::string name_;

    void on_failure(const mqtt::token &tok) override
    {
        std::cout << name_ << " failure";
        if (tok.get_message_id() != 0)
            std::cout << " for token: [" << tok.get_message_id() << "]" << std::endl;
        std::cout << std::endl;
    }

    void on_success(const mqtt::token &tok) override
    {
        std::cout << name_ << " success";
        if (tok.get_message_id() != 0)
            std::cout << " for token: [" << tok.get_message_id() << "]" << std::endl;
        auto top = tok.get_topics();
        if (top && !top->empty())
            std::cout << "\ttoken topic: '" << (*top)[0] << "', ..." << std::endl;
        std::cout << std::endl;
    }

public:
    action_listener(const std::string &name) : name_(name) {}
};

class callback : public virtual mqtt::callback,
                 public virtual mqtt::iaction_listener

{
    int nretry_;
    mqtt::async_client &cli_;
    mqtt::connect_options &connOpts_;
    action_listener subListener_;

    void reconnect()
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(2500));
        try
        {
            cli_.connect(connOpts_, nullptr, *this);
        }
        catch (const mqtt::exception &exc)
        {
            std::cerr << "Error: " << exc.what() << std::endl;
            exit(1);
        }
    }

    void on_failure(const mqtt::token &tok) override
    {
        std::cout << "Connection attempt failed" << std::endl;
        if (++nretry_ > N_RETRY_ATTEMPTS)
            exit(1);
        reconnect();
    }

    void on_success(const mqtt::token &tok) override {}

    void connected(const std::string &cause) override
    {
        std::cout << "\nConnection success" << std::endl;
        std::cout << "\nSubscribing to topic '" << TOPIC << "'\n"
                  << "\tfor client " << CLIENT_ID
                  << " using QoS" << QOS << "\n"
                  << "\nPress Q<Enter> to quit\n"
                  << std::endl;

        cli_.subscribe(TOPIC, QOS, nullptr, subListener_);
    }

    void connection_lost(const std::string &cause) override
    {
        std::cout << "\nConnection lost" << std::endl;
        if (!cause.empty())
            std::cout << "\tcause: " << cause << std::endl;

        std::cout << "Reconnecting..." << std::endl;
        nretry_ = 0;
        reconnect();
    }

    void message_arrived(mqtt::const_message_ptr msg) override
    {
        std::cout << "Message arrived" << std::endl;
        std::cout << "\ttopic: '" << msg->get_topic() << "'" << std::endl;
        // std::cout << "\tpayload: '" << msg->to_string()<< "'\n"<< std::endl; 

        std::vector<std::vector<double>> receive_results;
        cn::seisys::v2x::pb::VsmData vsmdata;
        vsmdata.ParseFromString(msg->get_payload());
        cn::seisys::v2x::pb::Position3D position3d = vsmdata.pos();
        // long int lat = position3d.lat();
        // long int lon = position3d.lon();
        // long int ele = position3d.ele();
        u_int64_t timestamp = vsmdata.timestamp();
        std::cout << "timestamp: " << timestamp << std::endl;
        std::string obuId = vsmdata.obuid();
        std::cout << "obuId: " << obuId << std::endl;
        double heading = 0.0125 * vsmdata.heading()  ;
        std::cout << "heading: " << std::fixed << std::setprecision(4) << heading << " deg" <<std::endl;
        double utmX = 1e-2 * position3d.lon();
        std::cout << "utmX: " << std::fixed << std::setprecision(2) << utmX << " m" <<std::endl;
        double utmY = 1e-2 * position3d.lat();
        std::cout << "utmY: " << std::fixed << std::setprecision(2) << utmY << " m" <<std::endl;
        double speed = 0.02 * vsmdata.speed();
        std::cout << "speed: " << std::fixed << std::setprecision(2) << speed << " m/s" <<std::endl;

        int participant_size = vsmdata.participants_size();
        std::vector<cn::seisys::v2x::pb::ParticipantData> participants;
        for(int participant_count = 0; participant_count < participant_size; participant_count++)
            participants.push_back(vsmdata.participants(participant_count));
        int obstacle_size = vsmdata.obstacles_size();
        std::vector<cn::seisys::v2x::pb::ObstacleData> obstacles;
        for(int obstacle_count = 0; obstacle_count<obstacle_size; obstacle_count++)
            obstacles.push_back(vsmdata.obstacles(obstacle_count));
        double utme, utmn;
        receive_results.push_back({speed,utme,utmn});

        //std::cout << "GOT message:\n" << utme<< "\t" << utmn << std::endl;
        std::cout <<"--------------------------------------------\n"<< std::endl;
        //std::cout << "\tGot_Message: '" << vsmdata.DebugString()<< "'\n";
    }

    void delivery_complete(mqtt::delivery_token_ptr token) override {}

public:
    callback(mqtt::async_client &cli, mqtt::connect_options &connOpts)
        : nretry_(0), cli_(cli), connOpts_(connOpts), subListener_("Subscription") {}
};

int main(int argc, char *argv[])
{
    mqtt::connect_options connOpts;
    connOpts.set_keep_alive_interval(20);
    connOpts.set_clean_session(true);
    connOpts.set_password(PASSWORD);

    mqtt::async_client client(SERVER_ADDRESS, CLIENT_ID);

    callback cb(client, connOpts);
    client.set_callback(cb);

    try
    {
        std::cout << "Connecting to the MQTT server..." << std::flush;
        client.connect(connOpts, nullptr, cb);
    }
    catch (const mqtt::exception &)
    {
        std::cerr << "\nERROR: Unable to connect to MQTT server: '"
                  << SERVER_ADDRESS << "'" << std::endl;
        return 1;
    }

    while (std::tolower(std::cin.get()) != 'q')
        ;

    try
    {
        std::cout << "\nDisconnecting from the MQTT server..." << std::flush;
        client.disconnect()->wait();
        std::cout << "OK" << std::endl;
    }
    catch (const mqtt::exception &exc)
    {
        std::cerr << exc.what() << std::endl;
        return 1;
    }

    return 0;
}


    